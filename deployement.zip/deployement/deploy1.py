import streamlit as st
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score    
import os

# Title of the app
st.title('Clustering with KMeans')

# File upload section
st.header("Upload a CSV File")
uploaded_file = st.file_uploader("cinema_merged_data_modifiedcolumns.csv", type="csv")

if uploaded_file is not None:
    try:
        # Read the uploaded CSV file
        data = pd.read_csv(uploaded_file)

        # Check if the dataset is empty
        if data.empty:
            st.error("The uploaded file is empty!")
        else:
            st.write("Dataset Preview:")
            st.dataframe(data.head())  # Preview of the uploaded data

            # Calculate silhouette coefficients for k values from 2 to 8
            silhouette_coefficients = []
            for k in range(2, 9):
                kmeans = KMeans(n_clusters=k, random_state=42)
                kmeans.fit(data)
                score = silhouette_score(data, kmeans.labels_)
                silhouette_coefficients.append([k, score])

            # Determine the best k (highest silhouette score)
            best_k = max(silhouette_coefficients, key=lambda x: x[1])[0]

            # Build the final KMeans model with the optimal number of clusters
            best_model = KMeans(n_clusters=best_k, random_state=42)
            data['cluster'] = best_model.fit_predict(data)  # Adding the 'cluster' column

            # Display results
            st.header("Clustering Results")
            st.write(f"Best K (Optimal Clusters): {best_k}")
            
            # Silhouette Scores
            st.subheader("Silhouette Scores for Different K Values:")
            silhouette_df = pd.DataFrame(silhouette_coefficients, columns=['K', 'Silhouette Score'])
            st.write(silhouette_df)

            # Display the clustered data (with the new 'cluster' column)
            st.subheader("Preview of Clustered Data:")
            st.dataframe(data)  # Show the entire dataset with the 'cluster' column

    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
